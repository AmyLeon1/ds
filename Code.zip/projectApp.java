import java.util.Scanner;

public class projectApp{

    static final int MAX_NUM_ITEMS = 5;
    static MenuTestClass [] projects = new MenuTestClass[MAX_NUM_ITEMS];

    //welcome message method
    public static void displayWelcome(){
        System.out.println("Welcome to our app!");
        System.out.println("                   ");
        System.out.println("You can enter the length of projects up to 5  here.");
        System.out.println("                                ");
    }
    //menu method
    static void menu(){
        System.out.println("Application Menu - Item type: Project");
        System.out.println("1 - Add an item ");
        System.out.println("2 - Display all items ");
        System.out.println("3 - Search and display all the items whose mandatory state is the same given value ");
        System.out.println("4 - Calculate and display the average value of the mandatory state of all the items entered until that point ");
        System.out.println("5 - Item with the highest mandatory state ");
        System.out.println("6 - Exit");
    }

    //main method
    public static void main(String[] args){


        Scanner in = new Scanner(System.in);

        //display welcome message
        displayWelcome();

        //display menu
        menu();

        //variable declaration to store users choice from menu
        int  choice;


        MenuTestClass calc = new MenuTestClass(); // to make object of MenuTestClass

        choice = in.nextInt();



       int count=0;
        while(true){


            switch (choice){

                case 1:

                    Scanner sc = new Scanner(System.in);

                    if (count >= projects.length) {
                        System.out.println("Limit exceeded");
                        break;
                    }

                    System.out.println("** Only projects with a duration between 2 and 12 months can be included **");
                    System.out.println("What is the duration of your projects in months?");

                    int duration = sc.nextInt();

                    while (duration < 2 || duration > 12){
                        System.out.println("Your duration input is wrong. Please enter between 2 and 12");
                        duration = sc.nextInt();
                    }

                    System.out.println("Enter the project name");
                    String projectName = sc.next();


                    System.out.println("Enter the manager name");
                    String managerName = sc.next();


                    projects[count]= new MenuTestClass(projectName, managerName, duration);
                    count++;

                    break;


                case 2:

                    boolean empty = false;
                    //int to say if array is empty
                    int i = 0;
                    System.out.println("You have entered the following values: ");
                    //travers the array to check if bool is not equal to zero
                    for(i=0; i < projects.length; i++){
                        if(projects[i] != null){
                            empty = true;
                            {System.out.println("Project name: "+projects[i].getProName() + " "+"Manager name: "+ projects[i].getManagerName()+ " "+"Duration: "+projects[i].getMyMonths());}
                        }
                    }

                    if(!empty){
                        System.out.println("Oops. No value entered yet.");
                    }
                    break;

                case 3:
                    //display all elements with the same state
                    //get number user wishes to search for

                    boolean found = false;
                    Scanner input = new Scanner(System.in);
                    System.out.print("Please enter the number you wish to search for");

                    //read user input
                   int num = input.nextInt();

                    //traverse array
                    int k = 0;
                    for(k=0; k < count; k++){
                        if(projects[k].getMyMonths() == num){
                            found = true;
                            System.out.println("A project with value " + num + " has been found at array index " + k);

                        }

                    }
                    if(!found){System.out.println("not found");}
                    break;


                //display averages
                case 4:
                    System.out.println("Choice 4 selected\n");
                    calc.calculateAverage(projects,count);
                    break;


                case 5:


                    // use the getter method to retrieve the maximum value
                    calc.calculateMax(projects, count); //call calculateMax method  // display the maximum value
                    break;

                case 6:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Please enter a valid number");
                    break;

            }


            Scanner sc = new Scanner(System.in);
            menu();
            choice = sc.nextInt();
        }

    }
}


