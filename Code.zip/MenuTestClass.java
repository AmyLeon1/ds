public class MenuTestClass{

    private String proName;
    private String managerName;
    private int myMonths;
    private double average; //store average value of numbers
    private boolean averageCanBeCalculated;
    private int max; // store max number from array. to be calculated


    //default constructor
    public MenuTestClass() {
    }

    //parameterized constructor
    public MenuTestClass(String proName, String managerName,int myMonths){
        this.myMonths = myMonths;
        this.proName = proName;
        this.managerName = managerName;
    }




    //setters
    public void setProName(String proName) {
        this.proName = proName;
    }

    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }

    public void setMyMonths(int duration){ //declare setter method
        myMonths = duration;}



    //getters
    public String getProName() {
        return this.proName;
    }

    public String getManagerName() {
        return this.managerName;
    }

    public int getMyMonths() {
        return this.myMonths;
    }

    //getter method to retrieve average
    public double getAverage(){
        return average;
    }

    // getter method to retrive the val of bool variable, shows if it could be calculated
    public boolean getAverageCanBeCalculated(){
        return averageCanBeCalculated;
    }


        public void calculateAverage(MenuTestClass[] array, int count){
            averageCanBeCalculated = false;

            //declare local variable to store sum of all elements
            int sum = 0;
            if(count != 0){
                for(int i=0; i < count; i++){
                    sum = sum + array[i].getMyMonths();
                } //for loop bracket

                //work out average

                average = (double) sum/count;
                System.out.println("average of the project duration is: "+average);
                averageCanBeCalculated = true;
            }
   }


        public void calculateMax(MenuTestClass[] array, int count){

            //store the first element of array in max variable
            max = array[0].getMyMonths();

            //traverse array  & compare max variable with current element of array
            for(int i = 1; i < count; i++){
                if(array[i].getMyMonths()>max){ //we found a larger number
                    max = array[i].getMyMonths(); //store max with the number of the array
                }
            }
            System.out.println("maximum project duration found is " + max);

        }
    }